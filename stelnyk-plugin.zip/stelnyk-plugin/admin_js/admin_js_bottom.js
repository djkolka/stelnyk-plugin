$.noConflict();
jQuery( document ).ready(function( $ ) {
  // alert('"qqqq"');
});