
$(document).ready(function(){
    
$( ".secret" ).click(function() {
  $( ".container" ).toggle( "slow", function() {
    // Animation complete.
  });
});

// alert('Ваша версия jQuery ' + jQuery.fn.jquery);
});