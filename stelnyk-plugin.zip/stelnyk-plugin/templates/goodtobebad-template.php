<?php
/*
 * Template Name: Good to Be Bad
 * Description: A Page Template with a darker design.
 */
echo '<iframe width="1280" height="720" src="//www.youtube.com/embed/2Bls1KKDwmo" frameborder="0" allowfullscreen></iframe>';